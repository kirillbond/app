package com.example.exoplanets.data;
import com.example.exoplanets.data.entities.Root;

import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class Repository {

    private MutableLiveData<Root> liveData = new MutableLiveData<>();
    ExecutorService es = Executors.newSingleThreadExecutor();
    protected RemoteDataSource remoteDataSource;
    public Repository(){
        remoteDataSource = new RemoteDataSource();
    }
    public MutableLiveData<Root> ExoplanetsData(){
        es.execute(new Runnable() {
            @Override
            public void run() {
                Root root = remoteDataSource.getExoplanets();
                liveData.postValue(root);
            }
        });
        return liveData;
    }

}
