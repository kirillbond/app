package com.example.exoplanets.data;
import com.example.exoplanets.data.entities.Root;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;
public interface ExoplanetsApi {
    @GET("/exoplanets.json")
    Call<Root> getexoplanets();
}
