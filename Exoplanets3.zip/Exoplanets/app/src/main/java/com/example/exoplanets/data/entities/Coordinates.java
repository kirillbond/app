package com.example.exoplanets.data.entities;

public class Coordinates
{
    private String system;
    private double right_ascension;
    private String right_ascension_units;
    private double declination;
    private String declination_units;
    private int epoch;
    public void setSystem(String system){
        this.system = system;
    }
    public String getSystem(){
        return this.system;
    }
    public void setRight_ascension(double right_ascension){
        this.right_ascension = right_ascension;
    }
    public double getRight_ascension(){
        return this.right_ascension;
    }
    public void setRight_ascension_units(String right_ascension_units){
        this.right_ascension_units = right_ascension_units;
    }
    public String getRight_ascension_units(){
        return this.right_ascension_units;
    }
    public void setDeclination(double declination){
        this.declination = declination;
    }
    public double getDeclination(){
        return this.declination;
    }
    public void setDeclination_units(String declination_units){
        this.declination_units = declination_units;
    }
    public String getDeclination_units(){
        return this.declination_units;
    }
    public void setEpoch(int epoch){
        this.epoch = epoch;
    }
    public int getEpoch(){
        return this.epoch;
    }
}
