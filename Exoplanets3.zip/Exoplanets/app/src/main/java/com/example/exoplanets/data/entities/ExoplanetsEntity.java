package com.example.exoplanets.data.entities;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Exo_entity")
public class ExoplanetsEntity {
    @PrimaryKey
    public Integer key;
    public String name;
}
