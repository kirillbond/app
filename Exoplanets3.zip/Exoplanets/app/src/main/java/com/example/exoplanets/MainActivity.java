package com.example.exoplanets;
import android.os.Bundle;
import android.widget.TextView;

import android.util.Log;

import com.example.exoplanets.data.RemoteDataSource;
import com.example.exoplanets.data.Repository;
import com.example.exoplanets.data.entities.Mass;
import com.example.exoplanets.data.entities.Root;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;


public class MainActivity extends AppCompatActivity implements Observer<Root>{
    String Tag = "!!!!";
    Repository rep = new Repository();
    MutableLiveData<Root> liveData = new MutableLiveData<Root>();
    RemoteDataSource remoteDataSource = new RemoteDataSource();
    TextView text1;
    TextView text2;
    TextView text3;
    TextView text4;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        remoteDataSource = new RemoteDataSource();
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        text3 = findViewById(R.id.text3);
        text4 = findViewById(R.id.text4);
        LiveData<Root> data = rep.ExoplanetsData();
        data.getValue();
        data.observe(this,this);
        Log.i(Tag, "OnCreate");
    }
   // public void print(Root root){
       /* String k = root.getResults().get(99).getName();
        text1.setText(k);
       */
  //  }
   @Override
    public void onChanged(Root root) {
       //if (root!=null)
        text1.setText(root.getResults().get(0).getName());
        double k1 = root.getCount();
        String k2 = String.valueOf(k1);
        text2.setText(k2);
        double k3 = root.getResults().get(0).getMass().getValue();
        text3.setText(Double.toString(k3));
    }
}
