package com.example.exoplanets.data.entities;

public class Results
{
    private String name;
    private Mass mass;
    private Coordinates coordinates;
    private Eccentricity eccentricity;
    private Omega_angle omega_angle;
    private Semi_major_axis semi_major_axis;
 /*
    private String radiuss;
    private String ainclination;

    private Orbital_period orbital_period;


    private String anomaly_angle;
    private String lambda_angle;
    private Time_periastron time_periastron;
    private String time_conjonction;
    private String angular_distance;
    private String atzero_primary_transit;
    private String tzero_secondary_transit;
    private String impact_parameter;
    private String tzero_radial_velocity;
    private Velocity_semiamplitude velocity_semiamplitude;
    private String acalculated_temperature;
    private String measuqred_temperature;
    private String hottest_point_longitude;
    private String ageometric_albedo;
    private String surface_gravity;
    private String detection_method;
    private String mass_detection_method;
    private String radius_detection_method;
    private String parent_star;
  */  public void setName(String name){
        this.name = name;
    }
    public String getName(){
        return this.name;
    }
    public void setMass(Mass mass){
    this.mass = mass;
}
    public Mass getMass(){
        return this.mass;
    }
    public void setCoordinates(Coordinates coordinates){
    this.coordinates = coordinates;
}
    public Coordinates getCoordinates(){
        return this.coordinates;
    }
    public void setEccentricity(Eccentricity eccentricity){
        this.eccentricity = eccentricity;
    }
    public Eccentricity getEccentricity(){
        return this.eccentricity;
    }
    public void setOmega_angle(Omega_angle omega_angle){
        this.omega_angle = omega_angle;
    }
    public Omega_angle getOmega_angle(){
        return this.omega_angle;
    }
    public void setSemi_major_axis(Semi_major_axis semi_major_axis){
    this.semi_major_axis = semi_major_axis;
}
    public Semi_major_axis getSemi_major_axis(){
        return this.semi_major_axis;
    }
  /*

    public void setRadius(String radius){
        this.radiuss = radius;
    }
    public String getRadius(){
        return this.radiuss;
    }
    public void setInclination(String inclination){
        this.ainclination = inclination;
    }
    public String getInclination(){
        return this.ainclination;
    }

    public void setOrbital_period(Orbital_period orbital_period){
        this.orbital_period = orbital_period;
    }
    public Orbital_period getOrbital_period(){
        return this.orbital_period;
    }
    public void setEccentricity(Eccentricity eccentricity){
        this.eccentricity = eccentricity;
    }
    public Eccentricity getEccentricity(){
        return this.eccentricity;
    }
    public void setOmega_angle(Omega_angle omega_angle){
        this.omega_angle = omega_angle;
    }
    public Omega_angle getOmega_angle(){
        return this.omega_angle;
    }
    public void setAnomaly_angle(String anomaly_angle){
        this.anomaly_angle = anomaly_angle;
    }
    public String getAnomaly_angle(){
        return this.anomaly_angle;
    }
    public void setLambda_angle(String lambda_angle){
        this.lambda_angle = lambda_angle;
    }
    public String getLambda_angle(){
        return this.lambda_angle;
    }
    public void setTime_periastron(Time_periastron time_periastron){
        this.time_periastron = time_periastron;
    }
    public Time_periastron getTime_periastron(){
        return this.time_periastron;
    }
    public void setTime_conjonction(String time_conjonction){
        this.time_conjonction = time_conjonction;
    }
    public String getTime_conjonction(){
        return this.time_conjonction;
    }
    public void setAngular_distance(String angular_distance){
        this.angular_distance = angular_distance;
    }
    public String getAngular_distance(){
        return this.angular_distance;
    }
    public void setTzero_primary_transit(String tzero_primary_transit){
        this.atzero_primary_transit = tzero_primary_transit;
    }
    public String getTzero_primary_transit(){
        return this.atzero_primary_transit;
    }
    public void setTzero_secondary_transit(String tzero_secondary_transit){
        this.tzero_secondary_transit = tzero_secondary_transit;
    }
    public String getTzero_secondary_transit(){
        return this.tzero_secondary_transit;
    }
    public void setImpact_parameter(String impact_parameter){
        this.impact_parameter = impact_parameter;
    }
    public String getImpact_parameter(){
        return this.impact_parameter;
    }
    public void setTzero_radial_velocity(String tzero_radial_velocity){
        this.tzero_radial_velocity = tzero_radial_velocity;
    }
    public String getTzero_radial_velocity(){
        return this.tzero_radial_velocity;
    }
    public void setVelocity_semiamplitude(Velocity_semiamplitude velocity_semiamplitude){
        this.velocity_semiamplitude = velocity_semiamplitude;
    }
    public Velocity_semiamplitude getVelocity_semiamplitude(){
        return this.velocity_semiamplitude;
    }
    public void setCalculated_temperature(String calculated_temperature){
        this.acalculated_temperature = calculated_temperature;
    }
    public String getCalculated_temperature(){
        return this.acalculated_temperature;
    }
    public void setMeasured_temperature(String measured_temperature){
        this.measuqred_temperature = measured_temperature;
    }
    public String getMeasured_temperature(){
        return this.measuqred_temperature;
    }
    public void setHottest_point_longitude(String hottest_point_longitude){
        this.hottest_point_longitude = hottest_point_longitude;
    }
    public String getHottest_point_longitude(){
        return this.hottest_point_longitude;
    }
    public void setGeometric_albedo(String geometric_albedo){
        this.ageometric_albedo = geometric_albedo;
    }
    public String getGeometric_albedo(){
        return this.ageometric_albedo;
    }
    public void setSurface_gravity(String surface_gravity){
        this.surface_gravity = surface_gravity;
    }
    public String getSurface_gravity(){
        return this.surface_gravity;
    }
    public void setDetection_method(String detection_method){
        this.detection_method = detection_method;
    }
    public String getDetection_method(){
        return this.detection_method;
    }
    public void setMass_detection_method(String mass_detection_method){
        this.mass_detection_method = mass_detection_method;
    }
    public String getMass_detection_method(){
        return this.mass_detection_method;
    }
    public void setRadius_detection_method(String radius_detection_method){
        this.radius_detection_method = radius_detection_method;
    }
    public String getRadius_detection_method(){
        return this.radius_detection_method;
    }
    public void setParent_star(String parent_star){
        this.parent_star = parent_star;
    }
    public String getParent_star(){
        return this.parent_star;
    }*/
}

