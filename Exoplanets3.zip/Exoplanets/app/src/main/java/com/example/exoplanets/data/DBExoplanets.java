package com.example.exoplanets.data;


import com.example.exoplanets.data.entities.ExoplanetsEntity;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;
@Dao
public interface DBExoplanets
{
    @Insert
    void insert(ExoplanetsEntity exoplanetsEntity);
    @Query("SELECT * FROM Exo_entity")
    public LiveData getDBExoplanets();
}
