package com.example.sample;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;

public class Main2Activity extends AppCompatActivity implements View.OnClickListener {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);
        Button button2 = (Button) findViewById(R.id.button2);
        button2.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                v.setVisibility(View.INVISIBLE);
            }
        }
        );
        Button button3 = (Button) findViewById(R.id.button3);
        button3.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                v.setVisibility(View.INVISIBLE); }
            }
        );
        Button button4 = (Button) findViewById(R.id.button4);
        button4.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                v.setVisibility(View.INVISIBLE); }
            }
        );
        Button button5 = (Button) findViewById(R.id.button5);
        button5.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                v.setVisibility(View.INVISIBLE); }
            }
        );
        Button button6 = (Button) findViewById(R.id.button6);
        button6.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v){
                v.setVisibility(View.INVISIBLE); }
        }
        );
        Button button7 = (Button) findViewById(R.id.button7);
        button7.setOnClickListener(new View.OnClickListener() {
                                       @Override public void onClick(View v){
                                           Button button7 = (Button) findViewById(R.id.button7);
                                           button7.setVisibility(View.INVISIBLE); }
                                   }
        );
        Button button8 = (Button) findViewById(R.id.button8);
        button8.setOnClickListener(new View.OnClickListener() {
                                       @Override public void onClick(View v){
                                           Button button8 = (Button) findViewById(R.id.button8);
                                           button8.setVisibility(View.INVISIBLE); }
                                   }
        );
        Button button9 = (Button) findViewById(R.id.button9);
        button9.setOnClickListener(new View.OnClickListener() {
                                       @Override public void onClick(View v){
                                           Button button9 = (Button) findViewById(R.id.button9);
                                           button9.setVisibility(View.INVISIBLE); }
                                   }
        );
        Button button10 = (Button) findViewById(R.id.button10);
        button10.setOnClickListener(new View.OnClickListener() {
                                       @Override public void onClick(View v){
                                           Button button10 = (Button) findViewById(R.id.button10);
                                           button10.setVisibility(View.INVISIBLE); }
                                   }
        );
        Button button11 = (Button) findViewById(R.id.button11);
        button11.setOnClickListener(new View.OnClickListener() {
                                        @Override public void onClick(View v){
                                            Button button11 = (Button) findViewById(R.id.button11);
                                            button11.setVisibility(View.INVISIBLE); }
                                    }
        );
        Button button12 = (Button) findViewById(R.id.button12);
        button12.setOnClickListener(new View.OnClickListener() {
                                        @Override public void onClick(View v){
                                            Button button12 = (Button) findViewById(R.id.button12);
                                            button12.setVisibility(View.INVISIBLE); }
                                    }
        );
    }
    public void onClick(View view){
        view.setVisibility(view.INVISIBLE);
    }

}
