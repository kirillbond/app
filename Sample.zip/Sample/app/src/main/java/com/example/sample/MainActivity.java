package com.example.sample;

import android.content.Intent;
import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    private static final String LOG_TAG = "MainActivity";
    SharedPreferences prefs;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.e(LOG_TAG, "OnCreate");
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences("prefs",MODE_PRIVATE);
        Button actButton = (Button)findViewById(R.id.button_act);
        actButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent();
                intent.setClass(getApplicationContext(), Main2Activity.class);
                startActivity(intent);
            }
        }
        );

    }

    @Override
    protected void onStart() {
        super.onStart();
        Log.e(LOG_TAG, "OnStart");
    }

    @Override
    protected void onResume() {
        super.onResume();
        Log.e(LOG_TAG, "OnResume");
        SharedPreferences prefs = getSharedPreferences( "prefs", MODE_PRIVATE);
        String out = prefs.getString("Log","------");
    }
    //you can see your activity
    @Override
    protected void onPause() {
        super.onPause();
        Log.e(LOG_TAG, "OnPause");
    }

    @Override
    protected void onStop() {
        super.onStop();
        Log.e(LOG_TAG, "OnStop");
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString("Log", "I was stopped");
        editor.commit();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        Log.e(LOG_TAG, "OnDEstroy");
    }
}
