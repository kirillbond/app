package com.example.exoplanets.data;

import com.example.exoplanets.data.entities.Root;

import androidx.room.Embedded;
import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "Exo_entity")
public class ExoplanetsEntity {
    @PrimaryKey(autoGenerate = true)
    public Integer id;
    public String name;//Root
    public double value;//Mass
    public String unit;
    public double error_max;
    public double error_min;
    public String bibcode;

    public String system;//Coordinates
    public double right_ascension;
    public String right_ascension_units;
    public double declination;
    public String declination_units;
    public int epoch;

    public double valueEc;//Eccentricity
    public double error_maxEc;
    public double error_minEc;
    public String bibcodeEc;

    public double omegaAnglevalue;//Omega_Angle
    public String omegaAngleunit;
    public double omegaAngleerror_max;
    public double omegaAngleerror_min;
    public String omegaAnglebibcode;

    public double semiMajorAxisvalue;//Semi_Major
    public String semiMajorAxisunit;
    public double semiMajorAxiserror_max;
    public double semiMajorAxiserror_min;
    public String semiMajorAxisbibcode;

}
