package com.example.exoplanets.data;
import android.content.Context;
import android.util.Log;

import com.example.exoplanets.data.entities.Root;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

public class Repository {
    private LocalDataSource localDataSource;
    private RemoteDataSource remoteDataSource;

    public Repository(Context context) {
        localDataSource = new LocalDataSource(context);
        remoteDataSource = new RemoteDataSource();
    }

    public LiveData<List<ExoplanetsEntity>> ExoplanetsData() {
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                Root root = remoteDataSource.getExoplanets();
                final List<ExoplanetsEntity> exList = new ArrayList<>();
                if (root != null) {
                    for (int i = 0; i < 100; i++) {
                        ExoplanetsEntity exoplanetsEntity = new ExoplanetsEntity();
                        exoplanetsEntity.id = i;
                        Log.e("Income", "id" + exoplanetsEntity.id);
                        exoplanetsEntity.name = root.getResults().get(i).getName();
                        Log.e("Income", "name" + exoplanetsEntity.name);
                        if(root.getResults().get(i).getMass()!=null) {
                            if(root.getResults().get(i).getMass().getUnit()!= null) {
                                exoplanetsEntity.unit = root.getResults().get(i).getMass().getUnit();
                            }
                            else{exoplanetsEntity.unit = "";}
                            Log.e("Income", "Mass.unit" + exoplanetsEntity.unit);
                            exoplanetsEntity.value = root.getResults().get(i).getMass().getValue();
                            exoplanetsEntity.error_max = root.getResults().get(i).getMass().getError_max();
                            exoplanetsEntity.error_min = root.getResults().get(i).getMass().getError_min();
                            if(root.getResults().get(i).getMass().getBibcode()!=null) {
                                exoplanetsEntity.bibcode = root.getResults().get(i).getMass().getBibcode();
                            }
                        }
                        else {exoplanetsEntity.bibcode = "";}
                        Log.e("Income", "error_max" + exoplanetsEntity.error_max);
                        Log.e("Income", "value_mass" + exoplanetsEntity.value);
                        Log.e("Income", "error_min" + exoplanetsEntity.error_min);


                        if(root.getResults().get(i).getEccentricity()!= null) {
                            exoplanetsEntity.valueEc = root.getResults().get(i).getEccentricity().getValue();
                            exoplanetsEntity.error_maxEc = root.getResults().get(i).getEccentricity().getError_max();
                            Log.e("Income", "declination_units" + exoplanetsEntity.error_maxEc);
                            exoplanetsEntity.error_minEc = root.getResults().get(i).getEccentricity().getError_min();
                            Log.e("Income", "declination_units" + exoplanetsEntity.error_minEc);
                            if(root.getResults().get(i).getEccentricity().getBibcode()!=null) {
                                exoplanetsEntity.bibcodeEc = root.getResults().get(i).getEccentricity().getBibcode();
                            }
                        }
                        else{exoplanetsEntity.bibcodeEc = "";}
                        Log.e("Income", "bibcodeEc" + exoplanetsEntity.bibcodeEc);
                        Log.e("Income", "valueEc" + exoplanetsEntity.valueEc);

                        if (root.getResults().get(i).getCoordinates() != null) {
                            if (root.getResults().get(i).getCoordinates().getSystem() != null) {
                                exoplanetsEntity.system = root.getResults().get(i).getCoordinates().getSystem();
                            } else {
                                exoplanetsEntity.system = "";
                            }
                            Log.e("Income", "system" + exoplanetsEntity.system);
                            exoplanetsEntity.right_ascension = root.getResults().get(i).getCoordinates().getRight_ascension();
                            Log.e("Income", "right_ascension" + exoplanetsEntity.right_ascension);
                            if (root.getResults().get(i).getCoordinates().getRight_ascension_units() != null) {
                                exoplanetsEntity.right_ascension_units = root.getResults().get(i).getCoordinates().getRight_ascension_units();
                            } else {
                                exoplanetsEntity.right_ascension_units = "";
                            }
                            Log.e("Income", "right_ascenasion_units" + exoplanetsEntity.right_ascension_units);
                            exoplanetsEntity.declination = root.getResults().get(i).getCoordinates().getDeclination();
                            exoplanetsEntity.epoch = root.getResults().get(i).getCoordinates().getEpoch();
                            Log.e("Income", "epoch" + exoplanetsEntity.epoch);
                            if(root.getResults().get(i).getCoordinates().getDeclination_units() != null){
                                exoplanetsEntity.declination_units = root.getResults().get(i).getCoordinates().getDeclination_units();
                            }
                        } else {
                            exoplanetsEntity.declination_units = "Not find";
                        }
                        Log.e("Income", "declination_units" + exoplanetsEntity.declination_units);
                        Log.e("Income", "declination" + exoplanetsEntity.declination);

                        if(root.getResults().get(i).getOmega_angle()!=null) {
                            exoplanetsEntity.omegaAnglevalue = root.getResults().get(i).getOmega_angle().getValue();
                            if(root.getResults().get(i).getOmega_angle().getUnit()!=null) {
                                exoplanetsEntity.omegaAngleunit = root.getResults().get(i).getOmega_angle().getUnit();
                            }
                            else{exoplanetsEntity.omegaAngleunit="°";}
                            exoplanetsEntity.omegaAngleerror_max = root.getResults().get(i).getOmega_angle().getError_max();
                            Log.e("Income", "oA" + exoplanetsEntity.omegaAngleerror_max);
                            exoplanetsEntity.omegaAngleerror_min = root.getResults().get(i).getOmega_angle().getError_min();
                            Log.e("Income", "Oa" + exoplanetsEntity.omegaAngleerror_min);
                            exoplanetsEntity.omegaAnglebibcode = "";//root.getResults().get(i).getOmega_angle().getBibcode();
                        }
                        else{exoplanetsEntity.omegaAnglebibcode ="";
                        exoplanetsEntity.omegaAngleunit="°";}
                        Log.e("Income", "omegaAnglebibcode" + exoplanetsEntity.omegaAnglebibcode);
                        Log.e("Income", "declination_units" + exoplanetsEntity.omegaAngleunit);
                        Log.e("Income", "declination_units" + exoplanetsEntity.value);
                        if(root.getResults().get(i).getSemi_major_axis()!=null) {
                            if (root.getResults().get(i).getSemi_major_axis().getBibcode() != null) {
                                exoplanetsEntity.semiMajorAxisbibcode = root.getResults().get(i).getSemi_major_axis().getBibcode();
                            } else {
                                exoplanetsEntity.semiMajorAxisbibcode = "";
                            }
                            if(root.getResults().get(i).getSemi_major_axis().getUnit()!=null) {
                                exoplanetsEntity.semiMajorAxisunit = root.getResults().get(i).getSemi_major_axis().getUnit();
                            }
                            else{exoplanetsEntity.semiMajorAxisunit ="";}
                            exoplanetsEntity.semiMajorAxisvalue = root.getResults().get(i).getSemi_major_axis().getValue();
                            exoplanetsEntity.semiMajorAxiserror_min = root.getResults().get(i).getSemi_major_axis().getError_min();
                            exoplanetsEntity.semiMajorAxiserror_max = root.getResults().get(i).getSemi_major_axis().getError_max();
                        }else{exoplanetsEntity.semiMajorAxisunit="AU";}

                        exList.add(i, exoplanetsEntity);
                    }
                    for (int j = 0; j < exList.size(); j++) {
                        Log.e("ForIncome", "" + exList.get(j).name);
                    }
                    Log.e("PostFor10000", "" + root.getResults().get(99).getCoordinates().getEpoch());
                    localDataSource.setExo(exList);
                }
            }
        });
        return localDataSource.getExo();
    }
}