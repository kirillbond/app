package com.example.exoplanets;
import android.os.Bundle;
import android.widget.TextView;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;

public class ItemActivity extends AppCompatActivity{
    private TextView declination_units;
    private TextView name;
    private TextView mass;
    private TextView right_ascension;
    private TextView eccentricity;
    private TextView omegaAngle;
    private TextView semiMajorAxis;
    private TextView massError;
    private String declination_untisd;
    private String named;
    private String massd;
    private String right_ascensiond;
    private String eccentricityd;
    private String omegaAngled;
    private String semiMajorAxisd;
    private String massErrord;
    @Override
    public void onCreate(Bundle savedInstanceState){
        super.onCreate(savedInstanceState);
        setContentView(R.layout.item_info);
        name = findViewById(R.id.item_1_5);
        named = getIntent().getStringExtra("name");
        name.setText(named);
        mass = findViewById(R.id.item_2);
        massd = getIntent().getStringExtra("mass");
        mass.setText(massd);
        massError = findViewById(R.id.item_3);
        massErrord = getIntent().getStringExtra("massError");
        massError.setText(massErrord);
        declination_units = findViewById(R.id.item_4);
        declination_untisd = getIntent().getStringExtra("declination_units");
        declination_units.setText(declination_untisd);
        right_ascension = findViewById(R.id.item_5);
        right_ascensiond = getIntent().getStringExtra("right_ascension");
        right_ascension.setText(right_ascensiond);
        eccentricity = findViewById(R.id.item_6);
        eccentricityd= getIntent().getStringExtra("eccentricity");
        eccentricity.setText(eccentricityd);
        omegaAngle = findViewById(R.id.item_7);
        omegaAngled = getIntent().getStringExtra("omegaAngle");
        omegaAngle.setText(omegaAngled);
        semiMajorAxis = findViewById(R.id.item_8);
        semiMajorAxisd = getIntent().getStringExtra("semiMajorAxis");
        semiMajorAxis.setText(semiMajorAxisd);
    }

}
