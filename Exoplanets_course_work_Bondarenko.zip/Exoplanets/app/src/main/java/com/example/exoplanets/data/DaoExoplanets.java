package com.example.exoplanets.data;


import com.example.exoplanets.data.entities.Root;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
@Dao
public interface DaoExoplanets
{
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insert(List<ExoplanetsEntity> exoplanetsEntity);
    @Query("SELECT * FROM Exo_entity")
    public LiveData<List<ExoplanetsEntity>> getDBExoplanets();
}
