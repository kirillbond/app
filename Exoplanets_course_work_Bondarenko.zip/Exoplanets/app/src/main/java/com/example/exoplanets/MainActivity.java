package com.example.exoplanets;
import android.os.Bundle;
import android.widget.TextView;
import android.util.Log;
import com.example.exoplanets.data.ExoplanetsEntity;
import com.example.exoplanets.data.RemoteDataSource;
import com.example.exoplanets.data.Repository;
import com.example.exoplanets.data.entities.Mass;
import com.example.exoplanets.data.entities.Root;

import java.util.ArrayList;
import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;


public class MainActivity extends AppCompatActivity implements Observer<List<ExoplanetsEntity>>{
    String Tag = "!!!!";
    private ExoplanetsAdapter mAdapter;
    private RecyclerView mNumbersList;
    private List<ExoplanetsEntity> eEntities0;
    private LiveData<List<ExoplanetsEntity>> eData;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        eData = new MutableLiveData<>();
        mNumbersList = findViewById(R.id.rec_list);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mNumbersList.setLayoutManager(layoutManager);
        mNumbersList.setHasFixedSize(true);
        eEntities0 = new ArrayList<>();
        mAdapter = new ExoplanetsAdapter(eEntities0);
        mNumbersList.setAdapter(mAdapter);
//maybe need to create field repository
        Repository repository = ((ExoplanetsApp)getApplicationContext()).getRepository();

        MainViewModel mainViewModel = ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.loadData(repository);
        eData = mainViewModel.getExoplanetsData();
        eData.observe(this,this);
        Log.i(Tag, "OnCreate");
    }

  //  }
   @Override
    public void onChanged(List<ExoplanetsEntity> root) {
        if (root!=null) {
            for (int i= 0; i < root.size(); i++) {
                Log.e("Outcome","" + root.get(i).name);
            }
            mAdapter.func(root);
        }
    }
}
