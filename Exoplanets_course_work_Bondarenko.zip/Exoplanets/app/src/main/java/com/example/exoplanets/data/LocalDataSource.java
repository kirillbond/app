package com.example.exoplanets.data;
import android.content.Context;

import com.example.exoplanets.data.entities.Root;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Room;
public class LocalDataSource {
    final DBExoplanets dataBase;

    public  LocalDataSource (Context context) {
        dataBase = Room.databaseBuilder(context, DBExoplanets.class, "Exo_entity").build();
    }
    public  void  setExo(List<ExoplanetsEntity> exoplanetsEntity) {
        dataBase.daoExoplanets().insert(exoplanetsEntity);
    }
    public LiveData<List<ExoplanetsEntity>> getExo() {
        return dataBase.daoExoplanets().getDBExoplanets();
    }
}
