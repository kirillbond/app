package com.example.exoplanets;


import android.content.Context;
import com.example.exoplanets.data.ExoplanetsEntity;
import com.example.exoplanets.data.Repository;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

public class MainViewModel extends ViewModel {
    //private Repository repository;
    LiveData<List<ExoplanetsEntity>> exoplanetsData;

    public void loadData(Repository repository1) {
        if(exoplanetsData == null) {
            exoplanetsData = repository1.ExoplanetsData();
        }
    }

    public LiveData<List<ExoplanetsEntity>> getExoplanetsData() {
        return exoplanetsData;
    }
}
