package com.example.exoplanets;
import android.app.Application;
import com.example.exoplanets.data.Repository;

public class ExoplanetsApp extends Application{
    private Repository repository;
    public void onCreate() {
        super.onCreate();
        repository = new Repository(this);
    }
    public Repository getRepository() {
        return repository;
    }
}
