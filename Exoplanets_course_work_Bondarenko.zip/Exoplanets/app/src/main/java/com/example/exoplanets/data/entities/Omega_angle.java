package com.example.exoplanets.data.entities;

public class Omega_angle
{
    private double value;
    private String unit;
    private double error_max;
    private double error_min;
    private String bibcode;
    public void setValue(double value){
        this.value = value;
    }
    public double getValue(){
        return this.value;
    }
    public void setUnit(String unit){
        this.unit = unit;
    }
    public String getUnit(){
        return this.unit;
    }
    public void setError_max(double error_max){
        this.error_max = error_max;
    }
    public double getError_max(){
        return this.error_max;
    }
    public void setError_min(double error_min){
        this.error_min = error_min;
    }
    public double getError_min(){
        return this.error_min;
    }
    public void setBibcode(String bibcode){
        this.bibcode = bibcode;
    }
    public String getBibcode(){
        return this.bibcode;
    }
}
