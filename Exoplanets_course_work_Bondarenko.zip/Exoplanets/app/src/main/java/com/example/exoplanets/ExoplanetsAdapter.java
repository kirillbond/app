package com.example.exoplanets;
import android.content.Context;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.exoplanets.data.ExoplanetsEntity;

import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
public class ExoplanetsAdapter extends RecyclerView.Adapter<ExoplanetsAdapter.NumberViewHolder>{
    private  static  int viewHolderCount;
    private int numberItems;
    private List<ExoplanetsEntity> exoEntities;
    public ExoplanetsAdapter(List<ExoplanetsEntity> ExoEntities1) {
        if (ExoEntities1.isEmpty()) {
            numberItems = 0;
        }
        else {
            numberItems = ExoEntities1.size();
        }
        exoEntities = ExoEntities1;
        viewHolderCount = 0;
    }
    public void func (List<ExoplanetsEntity> exoEntities1) {
        exoEntities = exoEntities1;
        notifyDataSetChanged();
    }@NonNull
    @Override
    public NumberViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        Context context = parent.getContext();
        int layoutIdForListItem = R.layout.exo_item;
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(layoutIdForListItem,parent,false);
        NumberViewHolder viewHolder = new NumberViewHolder(view);
        viewHolderCount++;
        return viewHolder;
    }
    @Override
    public void onBindViewHolder(@NonNull NumberViewHolder holder, int position) {
        holder.bind(exoEntities, position);
    }
    @Override
    public int getItemCount() {
        return exoEntities.size();
    }
    class NumberViewHolder extends RecyclerView.ViewHolder {

        TextView text8;
        private ExoplanetsEntity exoplanetsEntity;

        public NumberViewHolder(final View itemView) {
            super(itemView);
            text8 = itemView.findViewById(R.id.item_1);
            //new writing
            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Intent intent = new Intent();
                    intent.setClass(itemView.getContext(),ItemActivity.class);
                    intent.putExtra("declination_units", "Declination: " + String.valueOf(exoplanetsEntity.declination)+" "+exoplanetsEntity.declination_units);
                    intent.putExtra("mass","Mass: "+String.valueOf(exoplanetsEntity.value)+" "+exoplanetsEntity.unit);
                    intent.putExtra("name", "Name: "+exoplanetsEntity.name);
                    intent.putExtra("eccentricity", "Eccentricity: " + String.valueOf(exoplanetsEntity.valueEc));
                    intent.putExtra("right_ascension", "Right Ascension: "+String.valueOf(exoplanetsEntity.right_ascension)+" "+ exoplanetsEntity.right_ascension_units);
                    intent.putExtra("omegaAngle", "Omega angle: "+String.valueOf(exoplanetsEntity.omegaAnglevalue)+" "+exoplanetsEntity.omegaAngleunit);
                    intent.putExtra("semiMajorAxis", "Semi Major Axis: "+String.valueOf(exoplanetsEntity.semiMajorAxisvalue)+" "+ exoplanetsEntity.semiMajorAxisunit);
                    intent.putExtra("massError", "Maximum mass error: "+String.valueOf(exoplanetsEntity.error_max)+" "+"Minimum mass error: "+ String.valueOf(exoplanetsEntity.error_min));

                    itemView.getContext().startActivity(intent);
                }
            });
        }

        void bind(List<ExoplanetsEntity> exoEntities, int listIndex) {
            text8.setText(exoEntities.get(listIndex).name);
            exoplanetsEntity = exoEntities.get(listIndex);
        }
    }
}
