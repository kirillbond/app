package com.example.weather.data;
import android.content.Context;
import com.example.weather.data.entities.Root;
import java.util.List;
import androidx.lifecycle.LiveData;
import androidx.room.Room;
public class LocalDataSource {
    final WeatherDB db;
    final WeatherDB5Days db5Days;
    public LocalDataSource(Context context){
        db = Room.databaseBuilder(context, WeatherDB.class, "weather1Day").build();
        db5Days = Room.databaseBuilder(context, WeatherDB5Days.class,"wether5Days").build();
    }
    public void storeWeatherforDay(List<WeatherEntity> myDay){
        db.weatherDao().insertWeather(myDay);
    }
    public void storeWeatherforWeek(List<WeatherEntity5Days> myWeek){
        db5Days.weatherDaoForFiveDays().insertWeatherForWeek(myWeek);
    }
    public LiveData<List<WeatherEntity>> getWeahterDay(){
        return db.weatherDao().getWeather1Day();
    }
    public LiveData<List<WeatherEntity5Days>> getWeatherWeek(){
        return db5Days.weatherDaoForFiveDays().getWeatherForWeek();
    }

}
