package com.example.weather;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.example.weather.data.WeatherEntity5Days;

import java.util.ArrayList;
import java.util.List;
import androidx.lifecycle.ViewModel;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class WeekActivity extends AppCompatActivity implements Observer<List<WeatherEntity5Days>> {
    private WeatherAdapter mAdapter;
    private RecyclerView mNumbersList;
    private String city = "Odesa";
    private List<WeatherEntity5Days> weatherEntities;
    private LiveData<List<WeatherEntity5Days>> Data;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_5_days);
        Data = new MutableLiveData<>();

        mNumbersList = findViewById(R.id.rec_list);

        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        mNumbersList.setLayoutManager(layoutManager);

        mNumbersList.setHasFixedSize(true);
        weatherEntities = new ArrayList<>();
        mAdapter = new WeatherAdapter(weatherEntities);

        mNumbersList.setAdapter(mAdapter);

        MainViewModelFor5Days mainViewModelForFiveDays = ViewModelProviders.of(this).get(MainViewModelFor5Days.class);

        mainViewModelForFiveDays.loadData(this,city);

        Data = mainViewModelForFiveDays.getListLiveData();

        Data.observe(this,this);

    }

    @Override
    public void onChanged(List<WeatherEntity5Days> weatherEntities) {
        for (int i= 0; i < weatherEntities.size(); i++) {
            Log.e("Outcome","" + weatherEntities.get(i).temp);
        }
        mAdapter.func(weatherEntities);
    }
}
