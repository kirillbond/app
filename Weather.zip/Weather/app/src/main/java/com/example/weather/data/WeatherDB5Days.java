package com.example.weather.data;

import androidx.room.Database;
import androidx.room.RoomDatabase;

@Database(entities = {WeatherEntity5Days.class},version = 1,exportSchema = false)
public abstract class WeatherDB5Days extends RoomDatabase {
    public abstract WeatherDaoFor5Days weatherDaoForFiveDays();
}

