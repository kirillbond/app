package com.example.weather.data;
import android.content.Context;

import com.example.weather.data.entities.Root;
import com.example.weather.data.entities.RootFor5Days;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import androidx.lifecycle.LiveData;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

public class Repository {
    private LocalDataSource localDataSource;
    private RemoteDataSource remoteDataSource;
    public Repository(Context context){
        localDataSource = new LocalDataSource(context);
        remoteDataSource = new RemoteDataSource();
    }
    public LiveData<List<WeatherEntity>> getWeatherData1Day(final String city, final String API_KEY){
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                Root root = remoteDataSource.getWeatherByCityName(city, API_KEY);
                WeatherEntity weatherEntity = new WeatherEntity();
                weatherEntity.id = root.getId();
                final List<WeatherEntity> weatherEntityList = new ArrayList<>();
                weatherEntity.humidity = root.getMain().getHumidity();
                weatherEntity.pressure = root.getMain().getPressure();
                weatherEntity.temp = root.getMain().getTemp();
                weatherEntity.tempMax = root.getMain().getTemp_max();
                weatherEntity.tempMin = root.getMain().getTemp_min();
                weatherEntity.visibility = root.getVisibility();
                weatherEntity.windSpeed = root.getWind().getSpeed();
                weatherEntity.windDeg = root.getWind().getDeg();
                weatherEntityList.add(weatherEntity);
                localDataSource.storeWeatherforDay(weatherEntityList);
            }
        });
        return localDataSource.getWeahterDay();
    }
    public LiveData<List<WeatherEntity5Days>> getWeatherDataWeek(final String city, final String API_KEY){
        Executors.newSingleThreadExecutor().execute(new Runnable() {
            @Override
            public void run() {
                RootFor5Days rootFor5Days = remoteDataSource.getWeatherByCityNameForWeek(city, API_KEY);
                final List<WeatherEntity5Days> entity5DaysList= new ArrayList<>();
                for(int i=0; i<rootFor5Days.getList().size(); i++) {
                    WeatherEntity5Days weatherEntity5Days = new WeatherEntity5Days();
                    weatherEntity5Days.id = i;
                    weatherEntity5Days.dt = rootFor5Days.getList().get(i).getDt_txt();
                    weatherEntity5Days.temp = rootFor5Days.getList().get(i).getMain().getTemp();
                    weatherEntity5Days.windSpeed = rootFor5Days.getList().get(i).getWind().getSpeed();
                    weatherEntity5Days.humidity = rootFor5Days.getList().get(i).getMain().getHumidity();
                    entity5DaysList.add(weatherEntity5Days);
                }
                localDataSource.storeWeatherforWeek(entity5DaysList);
            }
        });
        return localDataSource.getWeatherWeek();
    }
    public void scheduleUpdate(){
        OneTimeWorkRequest request = new OneTimeWorkRequest.Builder(SyncWorker.class).build();
        WorkManager.getInstance().enqueue(request);
    }
}