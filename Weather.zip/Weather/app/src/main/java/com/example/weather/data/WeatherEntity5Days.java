package com.example.weather.data;



import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "tableForFiveDays")
public class WeatherEntity5Days {

    @PrimaryKey(autoGenerate = true)
    public int id;
    public String dt;
    public double temp;
    public double tempMin;
    public double tempMax;
    public double pressure;
    public double humidity;
    public double visibility;
    public double windSpeed;
    public double windDeg;
}

