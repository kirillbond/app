package com.example.weather.data;

import android.util.Log;

import com.example.weather.data.entities.Root;
import com.example.weather.data.entities.RootFor5Days;

import java.io.IOException;
import retrofit2.Call;
import retrofit2.Response;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RemoteDataSource {
    private WeatherService weatherService;
    public  RemoteDataSource(){
        Retrofit retrofit= new Retrofit.Builder()
                .baseUrl("http://api.openweathermap.org")
                .addConverterFactory(GsonConverterFactory.create())
                .build();
        weatherService = retrofit.create(WeatherService.class);
    }

    public Root getWeatherByCityName(String city, String Api_key){
        Call<Root> call=weatherService.getWeatherByCityName(city, Api_key);
        try{
            Response<Root> response = call.execute();
            if (response.isSuccessful()){
                return response.body();
            }
        }
        catch(IOException ioex){
            Log.e("Remote","IOEX"+ioex);
        }
            return null;
    }
    public RootFor5Days getWeatherByCityNameForWeek(String city, String Api_key){
        Call<RootFor5Days> call=weatherService.getWeatherByCityNameForWeek(city, Api_key);
        try{
            Response<RootFor5Days> response = call.execute();
            if(response.isSuccessful()){
                return response.body();
            }
        }
        catch(IOException ioex){
            Log.e("Remote",""+ioex);
        }
        return null;
    }
}
