package com.example.weather.data;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;
@Dao
public interface WeatherDao
{
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertWeather(List<WeatherEntity> weatherEntities);
    @Query("SELECT * FROM weather1day")
    LiveData<List<WeatherEntity>> getWeather1Day();
}
