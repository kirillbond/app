package com.example.weather.data.entities;

import java.util.ArrayList;
import java.util.List;
public class RootFor5Days
{
    private String cod;
    private double message;
    private int cnt;
    private List<MyList> list;
    private City city;
    public void setCod(String cod){
        this.cod = cod;
    }
    public String getCod(){
        return this.cod;
    }
    public void setMessage(double message){
        this.message = message;
    }
    public double getMessage(){
        return this.message;
    }
    public void setCnt(int cnt){
        this.cnt = cnt;
    }
    public int getCnt(){
        return this.cnt;
    }
    public void setList(List<MyList> list){
        this.list = list;
    }
    public List<MyList> getList(){
        return this.list;
    }
    public void setCity(City city){
        this.city = city;
    }
    public City getCity(){
        return this.city;
    }
}