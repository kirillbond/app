package com.example.weather;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.weather.data.WeatherEntity5Days;
import java.util.List;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class WeatherAdapter extends RecyclerView.Adapter<WeatherAdapter.WeatherHolder> {
    private static int weatherHolderCount;
    private int numberItems;
    private List<WeatherEntity5Days> entity5DaysList;
    public WeatherAdapter(List<WeatherEntity5Days> entity5DaysList1) {
        if (entity5DaysList1.isEmpty()){
            numberItems = 0;
        }else {
            numberItems = entity5DaysList1.size();
        }
        entity5DaysList = entity5DaysList1;
        weatherHolderCount = 0;
    }
    public void func(List<WeatherEntity5Days> entity5DaysList1){
        entity5DaysList = entity5DaysList1;
        notifyDataSetChanged();
    }

    class WeatherHolder extends RecyclerView.ViewHolder{
        private TextView text1;
        private TextView text2;
        private TextView text3;
        private TextView text4;
        public WeatherHolder(View view){
            super(view);
            text1 = view.findViewById(R.id.temperature);
            text2 = view.findViewById(R.id.pressure);
            text3 = view.findViewById(R.id.temp_min);
            text4 = view.findViewById(R.id.temp_max);
        }
        void bind(List<WeatherEntity5Days> entity5DaysList, int listIndex){
            text1.setText("Date: "+entity5DaysList.get(listIndex).dt);
            text2.setText("Humidity: "+String.valueOf(entity5DaysList.get(listIndex).humidity));
            text3.setText("Temperature: "+String.valueOf(entity5DaysList.get(listIndex).temp));
            text4.setText("Wind Speed: "+String.valueOf(entity5DaysList.get(listIndex).windSpeed));
        }
    }
    //?
    @NonNull
    @Override
    public WeatherHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i){
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.weather_1, viewGroup, false);
        weatherHolderCount++;
        return new WeatherHolder(view);
    }
    @Override
    public void onBindViewHolder(@NonNull WeatherHolder weatherHolder, int i){
        weatherHolder.bind(entity5DaysList, i);
    }
    @Override
    public int getItemCount(){
        return entity5DaysList.size();
    }

}
