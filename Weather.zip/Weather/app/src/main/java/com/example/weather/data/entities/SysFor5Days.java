package com.example.weather.data.entities;

public class SysFor5Days
{
    private String pod;

    public void setPod(String pod){
        this.pod = pod;
    }
    public String getPod(){
        return this.pod;
    }
}

