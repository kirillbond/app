package com.example.weather.data;

import androidx.room.Dao;
import androidx.room.Database;
import androidx.room.RoomDatabase;


@Database(entities = {WeatherEntity.class}, version = 2, exportSchema = false)
public abstract class WeatherDB extends RoomDatabase {
    public abstract WeatherDao weatherDao();
}
