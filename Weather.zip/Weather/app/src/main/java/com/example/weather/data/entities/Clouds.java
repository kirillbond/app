package com.example.weather.data.entities;
public class Clouds
{
    private int all;
    public void setAll(int all){
        this.all = all;
    }
    public int getAll(){
        return this.all;
    }
}
