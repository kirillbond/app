package com.example.weather;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.weather.data.WeatherEntity;
import com.example.weather.data.WeatherEntity5Days;

import java.util.List;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProviders;

public class OneDayActivity extends AppCompatActivity implements Observer<List<WeatherEntity>> {
    private String city = "Odesa";
    private static TextView text1;
    private static TextView text2;
    private static TextView text3;
    private static TextView text4;
    private static TextView text5;
    private static TextView text6;
    private static TextView text7;
    private static TextView text8;
    private static TextView text9;
    private LiveData<List<WeatherEntity>> Data;

    @Override
    public void onChanged(List<WeatherEntity> root) {
        if (root != null && !root.isEmpty()) {
            text1.setText(String.valueOf((double) (int) ((root.get(0).temp - 273.15) * 100) / 100));
            text2.setText(String.valueOf((double) (int) ((root.get(0).tempMin - 273.15) * 100) / 100));
            text3.setText(String.valueOf((double) (int) ((root.get(0).tempMax - 273.15) * 100) / 100));
            text4.setText(String.valueOf(root.get(0).pressure));
            text5.setText(String.valueOf(root.get(0).humidity));
            text6.setText(String.valueOf(root.get(0).visibility));
            text7.setText(String.valueOf(root.get(0).windSpeed));
            text8.setText(String.valueOf(root.get(0).windDeg));
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_for_1_day);
        text1 = findViewById(R.id.text1);
        text2 = findViewById(R.id.text2);
        text3 = findViewById(R.id.text3);
        text4 = findViewById(R.id.text4);
        text5 = findViewById(R.id.text5);
        text6 = findViewById(R.id.text6);
        text7 = findViewById(R.id.text7);
        text8 = findViewById(R.id.text8);
        text9 = findViewById(R.id.text9);


        MainViewModel mainViewModel =  ViewModelProviders.of(this).get(MainViewModel.class);
        mainViewModel.loadData(this, city);
        Data = mainViewModel.getWeatherData();
        Data.observe(this,this);
    }
}
