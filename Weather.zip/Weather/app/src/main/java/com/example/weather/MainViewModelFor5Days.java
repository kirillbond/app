package com.example.weather;

import android.content.Context;
import com.example.weather.data.Repository;
import com.example.weather.data.WeatherEntity;
import com.example.weather.data.WeatherEntity5Days;

import java.util.List;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;

public class MainViewModelFor5Days extends ViewModel{
    private Repository repository;
    LiveData<List<WeatherEntity5Days>> listLiveData;
    public void loadData(Context context, String city){
        if(listLiveData==null){
            repository = new Repository(context);
            listLiveData = repository.getWeatherDataWeek(city, context.getString(R.string.APPID));
            repository.scheduleUpdate();
        }
    }
    public LiveData<List<WeatherEntity5Days>> getListLiveData(){ return listLiveData;}
}
