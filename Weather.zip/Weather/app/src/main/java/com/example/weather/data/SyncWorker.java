package com.example.weather.data;
import android.content.Context;

import com.example.weather.WeatherApp;
import javax.xml.transform.Result;
import androidx.annotation.NonNull;
import androidx.work.ListenableWorker;
import androidx.work.Worker;
import androidx.work.WorkerParameters;
import android.app.Application;
import android.util.Log;

public class SyncWorker extends Worker{
    @NonNull
    @Override
    public Result doWork(){
        Repository repository = ((WeatherApp)getApplicationContext()).getRepository();
        Log.e("Worker","Working!!!");
        return ListenableWorker.Result.success();
    }
    public SyncWorker(Context context, WorkerParameters params){
        super(context, params);
    }
}

