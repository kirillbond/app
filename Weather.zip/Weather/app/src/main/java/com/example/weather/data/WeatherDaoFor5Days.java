package com.example.weather.data;

import java.util.List;

import androidx.lifecycle.LiveData;
import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.OnConflictStrategy;
import androidx.room.Query;

@Dao
public interface WeatherDaoFor5Days {
    @Query("SELECT * FROM tableForFiveDays")
    LiveData<List<WeatherEntity5Days>> getWeatherForWeek();

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    public void insertWeatherForWeek(List<WeatherEntity5Days> weatherEntities);
}
