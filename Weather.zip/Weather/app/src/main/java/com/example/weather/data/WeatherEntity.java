package com.example.weather.data;

import androidx.room.Entity;
import androidx.room.PrimaryKey;

@Entity(tableName = "weather1day")
public class WeatherEntity {

    @PrimaryKey(autoGenerate = true)
    public int id;
    public double temp;
    public double tempMin;
    public double tempMax;
    public double pressure;
    public double humidity;
    public double visibility;
    public double windSpeed;
    public double windDeg;
}