package com.example.weather.data;

import com.example.weather.data.entities.Root;
import com.example.weather.data.entities.RootFor5Days;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface WeatherService{
    @GET("/data/2.5/weather?")
    Call<Root> getWeatherByCityName(@Query("q") String city, @Query("APPID")String APPID);

    @GET("/data/2.5/forecast?")
    Call<RootFor5Days> getWeatherByCityNameForWeek(@Query("q") String city, @Query("APPID") String APPID);
}
