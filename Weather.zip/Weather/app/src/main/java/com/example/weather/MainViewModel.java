package com.example.weather;
import android.content.Context;
import com.example.weather.data.Repository;
import com.example.weather.data.WeatherEntity;
import java.util.List;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.ViewModel;


public class MainViewModel extends ViewModel {
    private Repository repository;
    LiveData<List<WeatherEntity>> weatherData;
    public void loadData(Context context, String city){
        if (weatherData == null) {
            repository = new Repository(context);
            weatherData = repository.getWeatherData1Day(city, context.getString(R.string.APPID));
            repository.scheduleUpdate();
        }
    }
    public LiveData<java.util.List<WeatherEntity>> getWeatherData(){
       return weatherData;
   }
}
